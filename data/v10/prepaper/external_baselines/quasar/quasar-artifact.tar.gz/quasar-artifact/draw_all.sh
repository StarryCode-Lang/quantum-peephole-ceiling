#!/bin/bash
# Master script: draw all paper figures.
# Usage:
#   bash draw_all.sh                          # use pre-computed data in results_provided/
#   DATA_DIR=results_local bash draw_all.sh   # use freshly generated results
set -euo pipefail

ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"

DATA="${DATA_DIR:-results_provided}"
OUT="figures"
mkdir -p "$OUT"

echo "=== Figure 14: time_vs_2qcount ==="
python3 scripts/draw_size_increasing_sample.py --out "$OUT/figure14.pdf"

echo ""
echo "=== Figure 15 (step 1): draw_2q -> figures/2q.csv ==="
python3 scripts/draw_2q.py "$DATA/compare.csv" \
    --out-dir "$OUT" \
    --sort ours \
    --quartz benchmarks/baselines/summary/quartz.csv \
    --queso  benchmarks/baselines/summary/queso.csv \
    --guoq   benchmarks/baselines/summary/guoq.csv \
    --tket   benchmarks/baselines/summary/tket.csv \
    --quarl  benchmarks/baselines/summary/quarl.csv

echo ""
echo "=== Figure 15 (step 2): comparison_merged 3x5 panel ==="
python3 scripts/draw_panel.py \
    --csv-2q "$OUT/2q.csv" \
    --csv-fid "$DATA/summary.csv" \
    --out "$OUT/figure15.pdf"

echo ""
echo "=== Figure 16: comparison_depth_total_step ==="
python3 scripts/draw_depth.py \
    --csv-depth "$DATA/baseline_depth.csv" \
    --runs-dir "$DATA/runs" \
    --summary-csv "$DATA/summary.csv" \
    --out "$OUT/figure16.pdf"

echo ""
echo "=== Figure 17: performance case studies (csla_mux_3 + radd_250) ==="
python3 scripts/draw_performance.py \
    "$DATA/performance_csla_mux_3.csv" \
    "$DATA/performance_radd_250.csv" \
    --out-prefix "$OUT/figure17a" \
    --out-prefix "$OUT/figure17b"

echo ""
echo "=== Figure 18: quality_time_log_2h_embedded ==="
FIG18_ARGS=(
    --merged-csv "$DATA/timelines/atomic_merged.csv"
    --baseline GuoQ:benchmarks/baselines/guoq.csv
    --baseline Qiskit:benchmarks/baselines/qiskit.csv
    --baseline Tket:benchmarks/baselines/tket.csv
    --baseline Quartz:benchmarks/baselines/quartz.csv
    --baseline Queso:benchmarks/baselines/queso.csv
    --log-x --max-time 7200 --num-points 60
    --case-list "$DATA/summary.csv"
    --out "$OUT/quality_time_log_2h.pdf"
    --out-embedded "$OUT/figure18.pdf"
)
if [ -f "$DATA/timelines/prefill_merged.csv" ]; then
    FIG18_ARGS+=(--prefill-csv "$DATA/timelines/prefill_merged.csv")
fi
python3 scripts/draw_quality_time.py "${FIG18_ARGS[@]}"

echo ""
echo "=== Figure 19: ablation (noschedule + noreorder) ==="
python3 scripts/draw_ablation_total.py \
    --ours       "$DATA/summary.csv" \
    --noguide    "$DATA/summary.noguide.csv" \
    --noilp      "$DATA/summary.noilp.csv" \
    --cmp        "$DATA/compare.csv" \
    --cmp_noguide "$DATA/compare.noguide.csv" \
    --cmp_noilp  "$DATA/compare.noilp.csv" \
    --out "$OUT/ablation.pdf" \
    --out-noschedule "$OUT/figure19a.pdf" \
    --out-noreorder "$OUT/figure19b.pdf"

echo ""
echo "=== Figure 19b: ablation_rule ==="
python3 scripts/draw_ablation_rule.py \
    --atomic   "$DATA/timelines/atomic_merged.csv" \
    --pairwise "$DATA/timelines/pairwise_merged.csv" \
    --raw      "$DATA/timelines/raw_merged.csv" \
    --out "$OUT/figure20.pdf" \
    --log-x --num-points 60 \
    --case-list "$DATA/summary.csv"

echo ""
echo "=== Cleaning intermediate files ==="
rm -f "$OUT"/*.png
rm -f "$OUT"/worse_than_*.csv "$OUT"/scatter_*.png "$OUT"/scurve_*.png
rm -f "$OUT"/2q.csv "$OUT"/quality_time_log_2h.pdf "$OUT"/quality_time_log_2h.csv

echo ""
echo "=== Done! Generated figures ==="
ls -lh "$OUT"/figure*.pdf 2>/dev/null || echo "(no figure PDFs found — check errors above)"